package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

/** Pacotes do sistema de quests (usa o mesmo canal de Net). */
public class QuestNet {
    public static void register() {
        int i = 20;
        Net.CH.registerMessage(i++, QSync.class, QSync::enc, QSync::dec, QSync::handle);
        Net.CH.registerMessage(i++, QSaveTab.class, QSaveTab::enc, QSaveTab::dec, QSaveTab::handle);
        Net.CH.registerMessage(i++, QDeleteTab.class, QDeleteTab::enc, QDeleteTab::dec, QDeleteTab::handle);
        Net.CH.registerMessage(i++, QSaveQuest.class, QSaveQuest::enc, QSaveQuest::dec, QSaveQuest::handle);
        Net.CH.registerMessage(i++, QDeleteQuest.class, QDeleteQuest::enc, QDeleteQuest::dec, QDeleteQuest::handle);
        Net.CH.registerMessage(i++, QEditRewards.class, QEditRewards::enc, QEditRewards::dec, QEditRewards::handle);
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    /** Quests filhas de uma quest restrita passam a ter a mesma restrição (senão ficariam travadas para os outros). */
    private static void cascadeClass(QuestData d, String parentId, String classId) {
        for (QuestDef x : d.quests.values()) {
            if (x.parent.equals(parentId) && !x.classId.equals(classId)) {
                x.classId = classId;
                cascadeClass(d, x.id, classId);
            }
        }
    }

    // ---------- servidor -> cliente ----------
    public record QSync(boolean open, CompoundTag data) {
        static void enc(QSync m, FriendlyByteBuf b) { b.writeBoolean(m.open); b.writeNbt(m.data); }
        static QSync dec(FriendlyByteBuf b) { return new QSync(b.readBoolean(), b.readNbt()); }
        static void handle(QSync m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientHooks.questSync(m.open, m.data)));
            c.get().setPacketHandled(true);
        }
    }

    // ---------- cliente -> servidor (só OP) ----------
    public record QSaveTab(CompoundTag tab) {
        static void enc(QSaveTab m, FriendlyByteBuf b) { b.writeNbt(m.tab); }
        static QSaveTab dec(FriendlyByteBuf b) { return new QSaveTab(b.readNbt()); }
        static void handle(QSaveTab m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                QuestTabDef t = QuestTabDef.load(m.tab);
                t.id = ClassDef.sanitize(t.id);
                if (t.id.isEmpty() || t.name.isBlank()) return;
                if (t.name.length() > 30) t.name = t.name.substring(0, 30);
                QuestData d = QuestData.get(p.server);
                QuestTabDef prev = d.tabs.get(t.id);
                if (!t.classId.isEmpty() && !ClassData.get(p.server).classes.containsKey(t.classId)
                        && !(prev != null && prev.classId.equals(t.classId))) t.classId = "";
                d.tabs.put(t.id, t);
                d.setDirty();
                QuestManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record QDeleteTab(String id) {
        static void enc(QDeleteTab m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static QDeleteTab dec(FriendlyByteBuf b) { return new QDeleteTab(b.readUtf(64)); }
        static void handle(QDeleteTab m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                QuestData d = QuestData.get(p.server);
                if (d.tabs.remove(m.id) == null) return;
                d.quests.values().removeIf(q -> q.tab.equals(m.id)); // apaga as quests da aba
                d.setDirty();
                QuestManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record QSaveQuest(CompoundTag quest) {
        static void enc(QSaveQuest m, FriendlyByteBuf b) { b.writeNbt(m.quest); }
        static QSaveQuest dec(FriendlyByteBuf b) { return new QSaveQuest(b.readNbt()); }
        static void handle(QSaveQuest m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                QuestData d = QuestData.get(p.server);
                QuestDef q = QuestDef.load(m.quest);
                q.id = ClassDef.sanitize(q.id);
                if (q.id.isEmpty() || q.name.isBlank() || !d.tabs.containsKey(q.tab)) return;
                if (q.name.length() > 40) q.name = q.name.substring(0, 40);
                if (q.description.length() > 200) q.description = q.description.substring(0, 200);
                q.amount = clamp(q.amount, 1, 1_000_000);
                q.xp = clamp(q.xp, 0, 1000);
                if (!q.type.needsTarget()) q.target = "";

                // pré-requisito: precisa existir, ser da mesma aba e não formar ciclo
                QuestDef par = d.quests.get(q.parent);
                if (par == null || !par.tab.equals(q.tab) || q.parent.equals(q.id)) q.parent = "";
                Set<String> seen = new HashSet<>();
                String cur = q.parent;
                while (!cur.isEmpty()) {
                    if (cur.equals(q.id) || !seen.add(cur)) { q.parent = ""; break; }
                    QuestDef n = d.quests.get(cur);
                    cur = n == null ? "" : n.parent;
                }

                QuestDef old = d.quests.get(q.id);
                q.rewards = old != null ? old.rewards : new ArrayList<>(); // recompensas só pelo baú
                // filtro de classe: precisa existir (ou já ser o antigo) e o filho herda a restrição do pai
                if (!q.classId.isEmpty() && !ClassData.get(p.server).classes.containsKey(q.classId)
                        && !(old != null && old.classId.equals(q.classId))) q.classId = "";
                QuestDef pp = q.parent.isEmpty() ? null : d.quests.get(q.parent);
                if (pp != null && !pp.classId.isEmpty()) q.classId = pp.classId;
                if (!q.classId.isEmpty()) cascadeClass(d, q.id, q.classId);
                d.quests.put(q.id, q);
                d.setDirty();
                QuestManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record QDeleteQuest(String id) {
        static void enc(QDeleteQuest m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static QDeleteQuest dec(FriendlyByteBuf b) { return new QDeleteQuest(b.readUtf(64)); }
        static void handle(QDeleteQuest m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                QuestData d = QuestData.get(p.server);
                QuestDef gone = d.quests.remove(m.id);
                if (gone == null) return;
                // os filhos passam a depender do "avô", mantendo a progressão
                for (QuestDef q : d.quests.values()) if (q.parent.equals(gone.id)) q.parent = gone.parent;
                d.setDirty();
                QuestManager.syncAll(p.server);
            });
            c.get().setPacketHandled(true);
        }
    }

    public record QEditRewards(String id) {
        static void enc(QEditRewards m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
        static QEditRewards dec(FriendlyByteBuf b) { return new QEditRewards(b.readUtf(64)); }
        static void handle(QEditRewards m, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || !p.hasPermissions(2)) return;
                QuestDef q = QuestData.get(p.server).quests.get(m.id);
                if (q != null) QuestRewardMenu.open(p, q);
            });
            c.get().setPacketHandled(true);
        }
    }
}
