package com.classselector;

import com.mojang.logging.LogUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.HumanoidArm;
import org.slf4j.Logger;

/**
 * Lado do cliente da Espada do Olho Sombrio: pose de "guarda baixa" com as duas mãos.
 * As mãos ficam juntas na frente do abdômen, com a espada saindo do punho, lâmina apontando
 * para frente e ~20° para baixo.
 *
 * Classe só de cliente: só é carregada via DarkEyeSwordItem#initializeClient.
 *
 * A orientação da espada na mão (display "thirdperson_*" em models/item/dark_eye_sword.json) foi calculada
 * para ESTES ângulos. Se mudar qualquer valor abaixo, o ângulo da espada na mão muda junto.
 */
public final class DarkEyeClient {
    private static final Logger LOGGER = LogUtils.getLogger();

    /** Braço que segura a espada (radianos): xRot negativo = para frente; yRot negativo = fecha para o centro (destro). */
    private static final float MAIN_X = -0.70F, MAIN_Y = -0.62F;
    /** Braço de apoio: cruza na frente do corpo até o cabo (yRot é espelhado para canhotos). */
    private static final float OFF_X = -0.94F, OFF_Y = 1.40F;

    /** Pose de braço customizada (duas mãos). Fica null se a Forge não conseguir criar o valor do enum. */
    public static final HumanoidModel.ArmPose LOW_GUARD = createPose();

    private DarkEyeClient() {}

    private static HumanoidModel.ArmPose createPose() {
        try {
            return HumanoidModel.ArmPose.create("CLASSSELECTOR_LOW_GUARD", true, (model, entity, arm) -> apply(model, arm));
        } catch (Throwable t) {
            LOGGER.warn("Nao foi possivel criar a pose de duas maos da Espada do Olho Sombrio; usando a pose padrao.", t);
            return null;
        }
    }

    private static void apply(HumanoidModel<?> model, HumanoidArm arm) {
        boolean right = arm == HumanoidArm.RIGHT;
        ModelPart main = right ? model.rightArm : model.leftArm;
        ModelPart off = right ? model.leftArm : model.rightArm;
        float side = right ? 1.0F : -1.0F; // espelha tudo para jogadores canhotos

        main.xRot = MAIN_X;
        main.yRot = side * MAIN_Y;
        main.zRot = 0.0F;

        off.xRot = OFF_X;
        off.yRot = side * OFF_Y;
        off.zRot = 0.0F;
    }
}
