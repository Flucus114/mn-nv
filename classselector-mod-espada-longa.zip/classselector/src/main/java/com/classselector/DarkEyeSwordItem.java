package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

/**
 * Espada do Olho Sombrio: cancela feitiços.
 *  - Ao acertar: interrompe a magia que o alvo estiver conjurando.
 *  - Clique direito: anula feitiços ao redor (conjurações em andamento, projéteis e áreas mágicas do Iron's Spells).
 * Sem receita e sem loot (como o Olho Cósmico): obtenha com /give classselector:dark_eye_sword.
 * Visual: espada longa, segurada com as duas mãos em guarda baixa (ver DarkEyeClient e models/item/dark_eye_sword.json).
 */
public class DarkEyeSwordItem extends SwordItem {
    /** Raio (blocos) e recarga (ticks) do clique direito; recarga curta quando não havia nada a anular. */
    public static final double DISPEL_RADIUS = 8.0D;
    public static final int DISPEL_COOLDOWN = 200, DISPEL_COOLDOWN_EMPTY = 20;

    public DarkEyeSwordItem() {
        super(Tiers.NETHERITE, 3, -2.4F, new Item.Properties().rarity(Rarity.EPIC).fireResistant());
    }

    /** Cliente: segura a espada com as duas mãos (pose em DarkEyeClient). */
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            @Nullable
            public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
                return hand == InteractionHand.MAIN_HAND ? DarkEyeClient.LOW_GUARD : null;
            }
        });
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean r = super.hurtEnemy(stack, target, attacker);
        if (!target.level().isClientSide && SpellCancel.interrupt(target)) {
            ServerLevel sl = (ServerLevel) target.level();
            sl.sendParticles(ParticleTypes.END_ROD, target.getX(), target.getY(0.6D), target.getZ(), 14, 0.4, 0.5, 0.4, 0.12);
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, target.getX(), target.getY(0.6D), target.getZ(), 20, 0.3, 0.4, 0.3, 0.3);
            sl.playSound(null, target.blockPosition(), SoundEvents.ENDER_EYE_DEATH, SoundSource.PLAYERS, 1.0F, 1.3F);
        }
        return r;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        if (!level.isClientSide) {
            int cancelled = 0;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(DISPEL_RADIUS),
                    x -> x != player && x.isAlive() && x.distanceToSqr(player) <= DISPEL_RADIUS * DISPEL_RADIUS)) {
                if (SpellCancel.interrupt(e)) cancelled++;
            }
            cancelled += SpellCancel.dispelEntities(level, player, DISPEL_RADIUS);

            ServerLevel sl = (ServerLevel) level;
            for (double r = 2.0D; r <= DISPEL_RADIUS; r += 2.0D) {
                for (int i = 0; i < 20; i++) {
                    double a = i * Math.PI / 10.0D;
                    sl.sendParticles(ParticleTypes.END_ROD, player.getX() + Math.cos(a) * r, player.getY() + 1.0D,
                            player.getZ() + Math.sin(a) * r, 1, 0.0, 0.05, 0.0, 0.02);
                }
            }
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1.0D, player.getZ(), 40, 0.6, 0.6, 0.6, 0.5);
            level.playSound(null, player.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.2F, 1.4F);

            player.getCooldowns().addCooldown(this, cancelled > 0 ? DISPEL_COOLDOWN : DISPEL_COOLDOWN_EMPTY);
            if (cancelled > 0) stack.hurtAndBreak(2, player, p -> p.broadcastBreakEvent(hand));
            player.displayClientMessage(Component.translatable("item.classselector.dark_eye_sword.dispelled", cancelled), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("item.classselector.dark_eye_sword.lore1").withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("item.classselector.dark_eye_sword.lore2")
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tips.add(Component.empty());
        tips.add(Component.translatable("item.classselector.dark_eye_sword.hit").withStyle(ChatFormatting.DARK_PURPLE));
        tips.add(Component.translatable("item.classselector.dark_eye_sword.dispel").withStyle(ChatFormatting.DARK_PURPLE));
        super.appendHoverText(stack, level, tips, flag);
    }
}
