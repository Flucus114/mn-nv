package com.classselector;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Aplica os bloqueios: uso com botão direito e crafting (resultado e ingredientes). */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class RestrictEvents {
    private static final Map<UUID, Long> LAST_MSG = new HashMap<>();

    private static void warn(Player p, String text) {
        if (p.level().isClientSide) return;
        long now = p.level().getGameTime();
        Long last = LAST_MSG.get(p.getUUID());
        if (last != null && now - last < 30) return;
        LAST_MSG.put(p.getUUID(), now);
        p.displayClientMessage(Component.literal(text), true);
    }

    private static final String USE_MSG = "Este item está bloqueado para a sua classe.";

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem e) {
        if (RestrictManager.isBlocked(e.getEntity(), e.getItemStack())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.FAIL);
            warn(e.getEntity(), USE_MSG);
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (RestrictManager.isBlocked(e.getEntity(), e.getItemStack())) {
            // o bloco ainda pode ser usado (abrir baú etc.), só o item é negado
            e.setUseItem(Event.Result.DENY);
            warn(e.getEntity(), USE_MSG);
        }
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract e) {
        if (RestrictManager.isBlocked(e.getEntity(), e.getItemStack())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.FAIL);
            warn(e.getEntity(), USE_MSG);
        }
    }

    @SubscribeEvent
    public static void onEntityInteractSpecific(PlayerInteractEvent.EntityInteractSpecific e) {
        if (RestrictManager.isBlocked(e.getEntity(), e.getItemStack())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.FAIL);
            warn(e.getEntity(), USE_MSG);
        }
    }

    /** Segurança extra: comer, beber, puxar arco, bloquear com escudo etc. */
    @SubscribeEvent
    public static void onUseStart(LivingEntityUseItemEvent.Start e) {
        if (e.getEntity() instanceof Player p && RestrictManager.isBlocked(p, e.getItem())) {
            e.setCanceled(true);
        }
    }

    /**
     * Crafting: se o resultado ou qualquer ingrediente for bloqueado, o resultado é esvaziado.
     * Vale para mesa de crafting, grade 2x2, bigorna, ferraria, cortador de pedra e menus de mods
     * que usem ResultContainer.
     */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        AbstractContainerMenu menu = p.containerMenu;
        if (menu == null) return;
        Set<String> rules = RestrictManager.rulesOf(p);
        if (rules.isEmpty()) return;

        boolean hasResult = false;
        boolean inputBlocked = false;
        for (Slot s : menu.slots) {
            if (s.container instanceof ResultContainer) {
                hasResult = true;
            } else if (!(s.container instanceof Inventory)) {
                ItemStack st = s.getItem();
                if (!st.isEmpty() && RestrictionData.matches(rules, st)) inputBlocked = true;
            }
        }
        if (!hasResult) return;

        boolean cleared = false;
        for (Slot s : menu.slots) {
            if (!(s.container instanceof ResultContainer)) continue;
            ItemStack out = s.getItem();
            if (out.isEmpty()) continue;
            if (inputBlocked || RestrictionData.matches(rules, out)) {
                s.set(ItemStack.EMPTY);
                cleared = true;
            }
        }
        if (cleared) {
            menu.broadcastChanges();
            warn(p, "Você não pode fabricar ou usar este item: bloqueado para a sua classe.");
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        LAST_MSG.remove(e.getEntity().getUUID());
    }
}
